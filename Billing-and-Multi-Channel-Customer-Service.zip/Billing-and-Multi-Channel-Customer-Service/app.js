// Import Firebase v9 modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, signOut } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";

// Firebase configuration
    const firebaseConfig = {
  apiKey: "AIzaSyBPxKN2ojQMzOuaE5zpPTjUuKBrYE8Sbag",
  authDomain: "elective-bf69a.firebaseapp.com",
  projectId: "elective-bf69a",
  appId: "1:610601934868:web:1ba1ebdfdc2ea83175c701"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Login function
window.login = function () {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  signInWithEmailAndPassword(auth, email, password)
    .then(() => {
      window.location.href = "dashboard.html";
    })
    .catch(error => {
      alert("Login failed: " + error.message);
    });
};

// Logout function
window.logout = function () {
  signOut(auth)
    .then(() => {
      window.location.href = "index.html";
    })
    .catch(error => {
      alert("Logout failed: " + error.message);
    });
};
